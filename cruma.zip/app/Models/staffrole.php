<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class staffrole extends Model
{
    public $table = 'staff_roles';
}
