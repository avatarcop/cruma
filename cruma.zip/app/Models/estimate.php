<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class estimate extends Model
{
    public $table = 'estimates';
}
