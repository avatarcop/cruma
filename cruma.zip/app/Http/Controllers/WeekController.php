<?php

namespace App\Http\Controllers;

use App\week;
use Illuminate\Http\Request;

class WeekController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\week  $week
     * @return \Illuminate\Http\Response
     */
    public function show(week $week)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\week  $week
     * @return \Illuminate\Http\Response
     */
    public function edit(week $week)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\week  $week
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, week $week)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\week  $week
     * @return \Illuminate\Http\Response
     */
    public function destroy(week $week)
    {
        //
    }
}
