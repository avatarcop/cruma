<?php

namespace App\Http\Controllers\User\controller;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Form;
use Illuminate\Support\Facades\Redirect;
use DB;
use Hash;
use Session;

use Response;

use \Carbon\Carbon;
use Validator;

class userController extends Controller
{
    
   
    public function index()
    {
        //
    }

   

   
}
