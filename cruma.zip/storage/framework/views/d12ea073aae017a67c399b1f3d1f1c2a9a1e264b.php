<?php $__env->startSection('content'); ?>

<div class="">
    <div class="page-title">
      <div class="title">
        <h3>Sistem Informasi Pengolahan Data KPI Karyawan</h3>
      </div>

      <div class="title_right">
        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
          <div class="input-group">
            <!-- <input type="text" class="form-control" placeholder="Search for...">
            <span class="input-group-btn">
              <button class="btn btn-default" type="button">Go!</button>
            </span> -->
          </div>
        </div>
      </div>
    </div>

    <div class="clearfix"></div>

    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Key Perfomance Indicator</h2>
            <!-- <ul class="nav navbar-right panel_toolbox">
              <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
              </li>
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="#">Settings 1</a>
                  </li>
                  <li><a href="#">Settings 2</a>
                  </li>
                </ul>
              </li>
              <li><a class="close-link"><i class="fa fa-close"></i></a>
              </li>
            </ul> -->
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
              <form name="grafikform" id="grafikformid" method="post">
                <?php echo e(csrf_field()); ?>

                <table width="auto">
                  <tr>
                    <td width="200" height="auto">Week</td>
                    <td>
                      <select name="week" class="form-control">
                      <?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k->id); ?>">Week <?php echo e($k->week); ?> (<?php echo e($k->tgl_awal); ?> - <?php echo e($k->tgl_akhir); ?>)</option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                      </select>
                    </td>
                  </tr>
                    <tr height="50" valign="bottom">
                      <td></td>
                      <td><button type="button" onclick="buka()" name="tes" class="btn btn-primary">Cari</button></td>
                    </tr>
                </table>
              </form>
              <br>
              <h4 style="display: none" id="programmer">Programmer</h3>
              <div id="chart_div2"></div>
              <br>
              <h4 style="display: none" id="analyst">Analyst</h3>
              <div id="chart_div"></div>
             
              
          </div>
        </div>
      </div>
    </div>
  </div>


<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
google.charts.load('current', {packages: ['corechart', 'bar']});
// google.charts.setOnLoadCallback(drawAnalyst);


function buka()
{
    var data = $('#grafikformid').serialize();

     $.ajax({
        type : "POST",
        url  : "<?php echo e(route('index.grafik')); ?>",
        data : data,

        success: function(response)
        {
          console.log('neh '+response)
            document.getElementById("analyst").style.display = "block";
            document.getElementById("programmer").style.display = "block";
            
            // Grafik Analyst
            var analyst = response.datagraph_analyst
            var data01 = [['Analyst Name', 'Scrum Total']];

            $.each(analyst, function (data, value) {
              data01.push([value.staff_name.toString(), value.total_scrum]);
            });


                var arr = $.makeArray(data01);
                var data = google.visualization.arrayToDataTable(arr);

                var materialOptions = {
                  chart: {
                    title: '',
                    subtitle: ''
                  },
                  hAxis: {
                    title: 'Analyst',
                    minValue: 0,
                  },
                  vAxis: {
                    title: 'Scrum Total',
                    gridlines: { count: 4 }

                  },
                  bars: 'horizontal'
                };

                var materialChart = new google.charts.Bar(document.getElementById('chart_div'));
                materialChart.draw(data, materialOptions);

                // var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
                // chart.draw(data, materialOptions);

          // Grafik Programmer
            var programmer = response.datagraph_programmer
            var data01 = [['Programmer Name', 'Scrum Total']];

            // $.each(programmer, function (data, value) {
            //   data01.push([value.staff_name.toString(), value.total_scrum]);
            // });

            //     var arr = $.makeArray(data01);
            //     var data = google.visualization.arrayToDataTable(arr);

            //     var materialOptions = {
            //       chart: {
            //         title: '',
            //         subtitle: ''
            //       },
            //       hAxis: {
            //         title: 'Programmer',
            //         minValue: 0,
            //       },
            //       vAxis: {
            //         title: 'Scrum Total'
            //       },
            //       bars: 'horizontal'
            //     };

            //     materialOptions.colors = [

            //     '#00cc00',
            //     'violet',
            //     'pink'
            //   ];


            //     var materialChart = new google.charts.ColumnChart(document.getElementById('chart_div2'));
                
            //     materialChart.draw(data, google.charts.Bar.convertOptions(materialOptions));

            $.each(programmer, function (data, value) {
              data01.push([value.staff_name.toString(), value.total_scrum]);
            });


                var arr = $.makeArray(data01);
                var data = google.visualization.arrayToDataTable(arr);

                var materialOptions = {
                  chart: {
                    title: '',
                    subtitle: ''
                  },
                  hAxis: {
                    title: 'Programmer',
                    minValue: 0,
                  },
                  vAxis: {
                    title: 'Scrum Total',
                    gridlines: { count: 4 }
                  },
                  bars: 'horizontal',
                };

                 materialOptions.colors = [
                    '#00cc00',
                    'violet',
                    'pink'
                  ];

                var materialChart = new google.charts.Bar(document.getElementById('chart_div2'));
                materialChart.draw(data, materialOptions);

                // var chart = new google.visualization.ColumnChart(document.getElementById('chart_div2'));
                // chart.draw(data, materialOptions);

                // materialChart.draw(data, google.charts.ColumnChart.convertOptions(materialOptions));
              



        }
      })
}




</script>
      
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>